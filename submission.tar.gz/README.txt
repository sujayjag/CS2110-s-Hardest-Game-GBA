CS 2110's Hardest Game

To play, first click enter to start the game from the homepage. You can click backspace at anytime to return home.

During gameplay, the player can use up, down, left and right arrows to move the red character around the screen. The goal is to collect all the yellow coins and reach the end green goal, while avoiding death by the purple enemies.
The Coins Collected and Death Counter keep track of coins, and deaths respectively.

If/When you win, you can click backspace to return back to the homepage from the win page.