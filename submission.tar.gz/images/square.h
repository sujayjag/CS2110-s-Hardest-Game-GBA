/*
 * Exported with nin10kit v1.8
 * Invocation command was nin10kit --mode=3 --resize=10x10 square square.png 
 * Time-stamp: Wednesday 03/30/2022, 23:21:08
 * 
 * Image Information
 * -----------------
 * square.png 10@10
 * 
 * All bug reports / feature requests are to be filed here https://github.com/TricksterGuy/nin10kit/issues
 */

#ifndef SQUARE_H
#define SQUARE_H

extern const unsigned short square[100];
#define SQUARE_SIZE 200
#define SQUARE_LENGTH 100
#define SQUARE_WIDTH 10
#define SQUARE_HEIGHT 10

#endif

